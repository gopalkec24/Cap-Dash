package com.exchange.resources;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;

import com.trade.impl.AutoTraderExecutor;

@Path("/trade")
public class TradingResource {

	public static final Logger LOGGER  = Logger.getLogger(ProfileResource.class.getName());
	
	@GET
	@Path("/PercentageBaseTrading")
	public Response performPercentageBaseTrading() {
		
		String jsonFilePath = "C:/Documents/autotradeData4.json";
		String traderType= "PercentageBaseTrader";
		long waitTimeInMS = 1000;
		int executionFrequency = 1;
		AutoTraderExecutor.startTrade(jsonFilePath, traderType, waitTimeInMS, executionFrequency);
		String response="";
		try {
			response = FileUtils.readFileToString(new File(jsonFilePath));
		} catch (IOException e) {
			LOGGER.severe(e.getMessage());
		}
		return Response.ok().entity(response).build();
	}
	
	@GET
	@Path("/RapidPercentageBaseTrading")
	public Response performRapidPercentageBaseTrading() {
		
		String jsonFilePath = "C:/Documents/autotradeData5.json";
		String traderType= "PercentageBaseTrader";
		long waitTimeInMS = 1000;
		int executionFrequency = 1;
		AutoTraderExecutor.startTrade(jsonFilePath, traderType, waitTimeInMS, executionFrequency);
		String response="";
		try {
			response = FileUtils.readFileToString(new File(jsonFilePath));
		} catch (IOException e) {
			LOGGER.severe(e.getMessage());
		}
		return Response.ok().entity(response).build();
	}
	
	@GET
	@Path("/FastPercentageBaseTrading")
	public Response performPercentageBaseTradingFast() {
		
		String jsonFilePath = "C:/Documents/autotradeData6.json";
		String traderType= "PercentageBaseTraderFast";
		long waitTimeInMS = 1000;
		int executionFrequency = 1;
		AutoTraderExecutor.startTrade(jsonFilePath, traderType, waitTimeInMS, executionFrequency);
		String response="";
		try {
			response = FileUtils.readFileToString(new File(jsonFilePath));
		} catch (IOException e) {
			LOGGER.severe(e.getMessage());
		}
		return Response.ok().entity(response).build();
	}
	
}
