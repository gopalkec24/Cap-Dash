package com.exchange.resources;


import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.trade.analysis.GetCoinmarketStatics;
import com.trade.analysis.dao.StaticsDataVO;
import com.trade.dao.coinmarketcap.CMCData;



@Path("/market")
public class StaticsResource {

	public static final Logger LOGGER  = Logger.getLogger(StaticsResource.class.getName());
	
	
	@GET
	@Path("/getStaticsReport")
	public Response performPercentageBaseTrading(			
			@QueryParam("time") String timeGap						
			) {
		
		String response="";
		List<CMCData> dataList = GetCoinmarketStatics.getGainerFilterByRank(100,timeGap);
		List<CMCData> dataList2 = GetCoinmarketStatics.getLoserFilterByRank(100,timeGap);
		ObjectMapper mapper = new ObjectMapper();
		StaticsDataVO data = new StaticsDataVO();
		data.setTopGain(dataList);
		data.setTopLoss(dataList2);
		try {
			response= mapper.writeValueAsString(data);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.ok().entity(response).build();
	}
}
