package com.exchange.resources;

import java.io.IOException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.portfolio.transaction.ReportGeneration;
import com.trade.BinanceTrade;

@Path("/exchanges")
public class RetrieveOpenOrders
{
	
	public Logger LOGGER  = Logger.getLogger(RetrieveOpenOrders.class.getName());
		
		@GET
		@Path("/getOpenOrders")
		public Response getOpenOrderFromExchange()
		{	
			BinanceTrade trade = new BinanceTrade();
			LOGGER.info(" I am logging now for testing " );;
			return Response.ok().entity(trade.getOrderDetails(null)).build();
			
		}
		
		@GET
		@Path("/getSummaryReport/{username}")
		public Response getSummaryReport(@PathParam("username") String userName) {
			String transactionFile = null;
			String configurationFile = null;
			String sumJsonLocation = null;
			if (userName!= null && userName.equalsIgnoreCase("gopal")) {
				transactionFile = "C:/Documents/MultiTransaction_1.csv";
				configurationFile = "C:/Documents/config.txt";
				sumJsonLocation = "C:/Documents/summaryJson.json";
			}
			else {
				
			}
			boolean saveReport=true;
			LOGGER.info("testing logger here");		
			String json = "";
			try {
				json = ReportGeneration.generateReport(transactionFile,configurationFile, sumJsonLocation, saveReport);
			} catch (IOException e) {
				return Response.serverError().build();
			} catch (Exception e) {
				return Response.serverError().build();
			}
			
		
			
			return Response.ok().entity(json).build();
			
		}
}
