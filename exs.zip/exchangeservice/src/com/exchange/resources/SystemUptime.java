package com.exchange.resources;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Path("/time")
public class SystemUptime {

	public static void main(String[] args) {
		SystemUptime up = new SystemUptime();
		up.logTime(null);
	}
	
	public static final Logger LOGGER = Logger.getLogger(SystemUptime.class.getName()) ;
	
	@GET
	@Path("/logTime")
	public Response logTime(String fileName1) {
		String fileName = "C:/Documents/upTime.json";
		LOGGER.info("Reading the upTime details");
		String ouputSom="[]";
		String readContent;
		try {
			readContent = readContentFromFile(fileName);
			Gson gson = new Gson();
			 Type listType = new TypeToken<List<Map<String,String>>>(){}.getType();
			// LOGGER.info("Content read is " + readContent);
			 List<Map<String,String>> configValues= gson.fromJson(readContent,listType);
			
			 Map<String,String> newDate= new HashMap<String,String>();
			 newDate.put("Date",new Date().toString());
			 configValues.add(newDate);
			 ObjectMapper mapper = new ObjectMapper();
			// System.out.println(configValues);
			 ouputSom = mapper.defaultPrettyPrintingWriter().writeValueAsString(configValues);
			writeContentToFile(fileName,ouputSom);
			LOGGER.info("Write completed the upTime details");
		} catch (IOException e) {
			LOGGER.severe(e.getMessage());
		}
		
		return Response.ok().entity(ouputSom).build();
	}

	private String readContentFromFile(String fileName) throws IOException {
		String content = FileUtils.readFileToString(new File(fileName));
		return content;
	}

	private void writeContentToFile(String fileName,String content) throws IOException {
		
		FileUtils.write(new File(fileName), content);
	}
}
