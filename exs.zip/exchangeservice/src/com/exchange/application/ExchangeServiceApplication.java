package com.exchange.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.exchange.resources.RetrieveOpenOrders;
import com.exchange.resources.StaticsResource;
import com.exchange.resources.SystemUptime;
import com.exchange.resources.TradingResource;

//@ApplicationPath("/api")
public class ExchangeServiceApplication extends Application {
	
	private Set<Object> singletons = new HashSet<Object>();
	
	
	public ExchangeServiceApplication() 
	{
		  singletons.add(new RetrieveOpenOrders());
		  singletons.add(new SystemUptime());
		  singletons.add(new TradingResource());
		  singletons.add(new StaticsResource());
		  
	}

	@Override
	public Set<Object> getSingletons() {
		
		return singletons;
	}
	

}
