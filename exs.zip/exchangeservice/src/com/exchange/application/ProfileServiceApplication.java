package com.exchange.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.exchange.resources.ProfileResource;


@ApplicationPath("/profile")
public class ProfileServiceApplication extends Application{


	private Set<Object> singletons = new HashSet<Object>();
	
	
	public ProfileServiceApplication() 
	{
		  singletons.add(new ProfileResource());
	}

	@Override
	public Set<Object> getSingletons() {
		
		return singletons;
	}
}
