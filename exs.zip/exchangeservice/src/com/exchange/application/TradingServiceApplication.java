package com.exchange.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.exchange.resources.TradingResource;

@ApplicationPath("/trading")
public class TradingServiceApplication extends Application {

private Set<Object> singletons = new HashSet<Object>();
	
	
	public TradingServiceApplication() 
	{
		  singletons.add(new TradingResource());
	}

	@Override
	public Set<Object> getSingletons() {
		
		return singletons;
	}
}
